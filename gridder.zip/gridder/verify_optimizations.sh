#!/bin/bash
# Script de Verificación Rápida - Optimizaciones en localizer.cpp
# Uso: bash verify_optimizations.sh

echo "════════════════════════════════════════════════════════════════"
echo "  VERIFICACIÓN RÁPIDA DE OPTIMIZACIONES EN localizer.cpp"
echo "════════════════════════════════════════════════════════════════"
echo

# Color para output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

PASSED=0
FAILED=0

# Función para verificar
check() {
    local desc="$1"
    local grep_pattern="$2"
    local file="$3"

    if grep -q "$grep_pattern" "$file"; then
        echo -e "${GREEN}✓${NC} $desc"
        ((PASSED++))
    else
        echo -e "${RED}✗${NC} $desc"
        ((FAILED++))
    fi
}

echo "📋 Verificando cambios en archivos..."
echo

# Verificaciones en localizer.h
echo "📄 localizer.h:"
check "  • Método getWeight() presente" "inline double getWeight()" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.h"

check "  • Constructor Particle presente" "Particle() = default" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.h"

echo

# Verificaciones en localizer.cpp
echo "📄 localizer.cpp:"
check "  • Include de unordered_set" "#include <unordered_set>" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

check "  • Hash function para tuple" "struct hash<std::tuple<int, int, int>>" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

check "  • unordered_set en resampleKLD" "std::unordered_set<Bin>" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

check "  • OpenMP habilitado en correct()" "#pragma omp parallel for" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

check "  • Validación isfinite en correct()" "std::isfinite(likelihood)" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

check "  • getWeight() en getEffectiveSampleSize()" "p.getWeight()" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

check "  • getWeight() en getMeanPose()" "w = p.getWeight()" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

check "  • getWeight() en getCovariance()" "w = p.getWeight().*dx" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

check "  • getWeight() en resample()" "cumulative\[0\] = particles_\[0\].getWeight()" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

check "  • getWeight() en drawParticles()" "double w = p.getWeight()" \
    "/home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp"

echo

# Contar referencias a getWeight()
echo "📊 Estadísticas:"
count_getweight=$(grep -o "getWeight()" /home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp | wc -l)
echo "  • Referencias a getWeight(): $count_getweight (esperado: 12+)"

count_exp=$(grep -o "std::exp(p.log_weight)" /home/usuario/robocomp/components/beta-robotica-class/gridder/src/localizer.cpp | wc -l)
if [ "$count_exp" -eq 0 ]; then
    echo -e "  ${GREEN}✓${NC} No hay std::exp(p.log_weight) duplicados"
    ((PASSED++))
else
    echo -e "  ${YELLOW}⚠${NC} Aún hay $count_exp referencias a std::exp(p.log_weight)"
fi

echo

# Verificar compilación
echo "🔨 Compilación:"
cd /home/usuario/robocomp/components/beta-robotica-class/gridder
if [ -f "build/CMakeCache.txt" ]; then
    echo -e "  ${GREEN}✓${NC} Build directory existe"
    ((PASSED++))

    if [ -f "bin/gridder" ]; then
        echo -e "  ${GREEN}✓${NC} Binario compilado existe"
        ((PASSED++))
    else
        echo -e "  ${RED}✗${NC} Binario no existe (ejecutar: make)"
        ((FAILED++))
    fi
else
    echo -e "  ${YELLOW}⚠${NC} Build directory no existe (ejecutar: cmake && make)"
fi

echo

# Resumen
echo "════════════════════════════════════════════════════════════════"
echo -e "RESULTADO: ${GREEN}$PASSED pasaron${NC}, ${RED}$FAILED fallaron${NC}"

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}✨ TODAS LAS OPTIMIZACIONES APLICADAS CORRECTAMENTE${NC}"
    exit 0
else
    echo -e "${RED}❌ FALTAN CAMBIOS - Revisar documentación${NC}"
    exit 1
fi


