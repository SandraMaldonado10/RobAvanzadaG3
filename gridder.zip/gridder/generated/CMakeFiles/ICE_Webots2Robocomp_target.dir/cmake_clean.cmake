file(REMOVE_RECURSE
  "CMakeFiles/ICE_Webots2Robocomp_target"
  "Webots2Robocomp.ice"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/ICE_Webots2Robocomp_target.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
